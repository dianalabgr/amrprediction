For escherichia coli download the 5s, 16s, 23s   rRNA sequence of the reference strain 
      (GCF_000005845.2) |     Escherichia coli str. K-12 substr. MG1655  |  Genome assembly ASM584v2
 from https://www.ncbi.nlm.nih.gov/datasets/gene/GCF_000005845.2/?search=16s     
 and also download this as reference strain 
 
 For acinetobacter baumannii https://www.ncbi.nlm.nih.gov/datasets/genome/GCF_008632635.1/
 
 For enterococcus faecium https://www.ncbi.nlm.nih.gov/datasets/gene/GCF_009734005.1/
 
 For enterobacter cloacae https://www.ncbi.nlm.nih.gov/datasets/gene/GCF_905331265.2/
 
 For Klebsiella pneumoniae https://www.ncbi.nlm.nih.gov/datasets/gene/GCF_000240185.1/?gene_type=rRNA
 
 For pseudomonas aeruginosa https://www.ncbi.nlm.nih.gov/datasets/gene/GCF_000006765.1/
 
 For staphylococcus aureus https://www.ncbi.nlm.nih.gov/datasets/genome/GCF_000013425.1/
